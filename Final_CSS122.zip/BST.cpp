#include <iostream>
#include "BST.h"
using namespace std;

//**************************************************
// This version of insert inserts a number into    *
// a given subtree of the main binary search tree. *
//**************************************************
void BinaryTree::insert(TreeNode*& tree, int num)
{
    // If the tree is empty, make a new node and make it 
    // the root of the tree.
    if (!tree)
    {
        tree = new TreeNode(num);
        return;
    }

    // If num is already in tree: return.
    if (tree->value == num)
        return;

    // The tree is not empty: insert the new node into the
    // left or right subtree.
    if (num < tree->value)
        insert(tree->left, num);
    else
        insert(tree->right, num);
}

//***************************************************
// destroySubTree is called by the destructor. It   *
// deletes all nodes in the tree.                   *
//***************************************************
void BinaryTree::destroySubtree(TreeNode* tree)
{
    if (!tree) return;
    destroySubtree(tree->left);
    destroySubtree(tree->right);
    // Delete the node at the root.
    delete tree;
    tree = nullptr;
}

//***************************************************
// searchNode determines if a value is present in   *
// the tree. If so, the function returns true.      *
// Otherwise, it returns false.                     *
//***************************************************
bool BinaryTree::search(int num) const
{
    TreeNode* tree = root;

    while (tree)
    {
        if (tree->value == num)
            return true;
        else if (num < tree->value)
            tree = tree->left;
        else
            tree = tree->right;
    }
    return false;
}

//********************************************
// remove deletes the node in the given tree *
// that has a value member the same as num.  *
//********************************************
void BinaryTree::remove(TreeNode*& tree, int num)
{
    if (tree == nullptr) return;
    if (num < tree->value)
        remove(tree->left, num);
    else if (num > tree->value)
        remove(tree->right, num);
    else
        // We have found the node to delete.
        makeDeletion(tree);
}

//***********************************************************
// makeDeletion takes a reference to a tree whose root      *
// is to be deleted. If the tree has a single child, the    *
// the tree is replaced by the single child after the       *    
// removal of its root node. If the tree has two children   *
// the left subtree of the deleted node is attached at      *
// an appropriate point in the right subtree, and then      *
// the right subtree replaces the original tree.            *
//***********************************************************
void BinaryTree::makeDeletion(TreeNode*& tree)
{
    // Used to hold node that will be deleted.
    TreeNode* nodeToDelete = tree;

    // Used to locate the  point where the 
    // left subtree is attached.
    TreeNode* attachPoint;

    if (tree->right == nullptr)
    {
        // Replace tree with its left subtree. 
        tree = tree->left;
    }
    else if (tree->left == nullptr)
    {
        // Replace tree with its right subtree.
        tree = tree->right;
    }
    else
        //The node has two children
    {
        // Move to right subtree.
        attachPoint = tree->left;

        // Locate the smallest node in the right subtree
        // by moving as far to the left as possible.
        while (attachPoint->right != nullptr)
            attachPoint = attachPoint->right;

        // Attach the left subtree of the original tree
        // as the left subtree of the smallest node 
        // in the right subtree.
        attachPoint->right = tree->right;

        // Replace the original tree with its right subtree.
        tree = tree->left;
    }

    // Delete root of original tree
    delete nodeToDelete;
    nodeToDelete = nullptr;
}

//*********************************************************
// This function displays the values  stored in a tree    *  
// in inorder.                                            *
//*********************************************************
void BinaryTree::displayInOrder(TreeNode* tree, ofstream &outfile)
{
    if (tree)
    {
        displayInOrder(tree->left, outfile);
        cout << tree->value << "  ";
        outfile << tree->value << " ";
        displayInOrder(tree->right, outfile);
    }
}

//*********************************************************
// This function displays the values stored in a tree     *
// in inorder.                                            *
//*********************************************************
void BinaryTree::displayPreOrder(TreeNode* tree, ofstream &outfile)
{
    if (tree)
    {
        cout << tree->value << "  ";
        outfile << tree->value << " ";
        displayPreOrder(tree->left, outfile);
        displayPreOrder(tree->right, outfile);
    }
}

//*********************************************************
// This function displays the values  stored  in a tree   *
// in postorder.                                          * 
//*********************************************************
void BinaryTree::displayPostOrder(TreeNode* tree, ofstream &outfile)
{
    if (tree)
    {
        displayPostOrder(tree->left, outfile);
        displayPostOrder(tree->right, outfile);
        cout << tree->value << "  ";
        outfile << tree->value << " ";
       
    }
}