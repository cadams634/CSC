#include "MyUtilities.h"
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

void MyUtilities::displayMenu(string &filename, int &num)
{
	cout << "Please enter the name of the file: ";
	cin >> filename;

	fstream inFile(filename);

	if (!inFile) throw string("Exception Thrown: File not found.");

	cout << "Please enter how many numbers to read from file (1-50): ";
	cin >> num;

	if (num < 1 || num > 50) throw string("Exception Thrown: Invalid input.");

	inFile.close();
}

int* MyUtilities::readData1(string filename, int num)
{
	int size = num;
	int value;
	int* iArray = new int[size];

	ifstream inFile(filename);

	if (filename != "data.txt")
		throw string("Exception Thrown: File not found.");

	for (int i = 0; i < num; i++)
	{
		inFile >> value;
		iArray[i] = value;
	}

	inFile.close();

	return iArray;
}

int* MyUtilities::readData2(int num)
{
	ifstream inFile("numbers.dat", ios::in, ios::binary);

	int* newArray = new int[num];

	int x = 0;
	if (inFile.is_open())
	{
		while (x < num)
		{
			inFile.read(reinterpret_cast<char*>(&newArray[x]), sizeof(newArray[x]));
			x++;
		}
		cout << "Numbers have been read from the binary file." << endl;
		
		inFile.close();
	}
	else
	{
		throw string("Exception Thrown: File not found.");
	}

	return newArray;
}

void MyUtilities::writeData(int numbers[], int size)
{
	ofstream outFile("numbers.dat", ios::out, ios::binary);

	int x = 0;
	if (outFile.is_open())
	{
		while (x < size)
		{
			outFile.write(reinterpret_cast<const char*>(&numbers[x]), sizeof(numbers[x]));
			x++;
		}
		cout << "Numbers have been written into a binary file." << endl;

		outFile.close();
	}
	else
	{
		throw string("Exception Thrown: File not found.");
	}
}
