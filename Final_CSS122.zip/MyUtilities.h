#pragma once
#include <string>
#include <vector>
using namespace std;

class MyUtilities
{
public:
	void displayMenu(string &filename, int &num);
	int* readData1(string filename, int num);
	int* readData2(int num);
	void writeData(int[], int size);

};