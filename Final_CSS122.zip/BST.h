#pragma once
#include <fstream>
using namespace std;

class BinaryTree
{
private:
    // The TreeNode struct is used to build the tree.
    struct TreeNode
    {
        int value;
        TreeNode* left;
        TreeNode* right;
        TreeNode(int value1,
            TreeNode* left1 = nullptr,
            TreeNode* right1 = nullptr)
        {
            value = value1;
            left = left1;
            right = right1;
        }
    };

    TreeNode* root;     // Pointer to the root of the tree

    // Various helper member functions.
    void insert(TreeNode*&, int);
    void destroySubtree(TreeNode*);
    void remove(TreeNode*&, int);
    void makeDeletion(TreeNode*&);
    void displayInOrder(TreeNode*, ofstream &);
    void displayPreOrder(TreeNode*, ofstream &);
    void displayPostOrder(TreeNode*, ofstream&);

public:
    // These member functions are the public interface.
    BinaryTree()		// Constructor
    {
        root = nullptr;
    }
    ~BinaryTree()		// Destructor
    {
        destroySubtree(root);
    }
    void insert(int num)
    {
        insert(root, num);
    }
    bool search(int) const;
    void remove(int num) //wrapper
    {
        remove(root, num);
    }
    void showInOrder(ofstream &outFile)
    {
        displayInOrder(root, outFile);
    }
    void showPreOrder(ofstream& outFile)
    {
        displayPreOrder(root, outFile);
    }
    void showPostOrder(ofstream& outFile)
    {
        displayPostOrder(root, outFile);
    }


};
