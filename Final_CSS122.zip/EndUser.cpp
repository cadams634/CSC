#include "BST.h"
#include "MyUtilities.h"
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int main()
{
	BinaryTree tree;
	MyUtilities myU;

	//Helper variables
	string filename = "";
	int numInts = 0;

	//sends helper variables to be assigned
	try
	{
		myU.displayMenu(filename, numInts);
	}
	catch (string e)
	{
		cout << e;
		return 0;
	};

	//allocation of memory to an array
	int* myArray = new int[numInts];

	//reading data from input file into an array
	try
	{
		myArray = myU.readData1(filename, numInts);
	}
	catch (string e)
	{
		cout << e;
		return 0;
	}

	//showing we did indeed get numbers from file
	cout << "\nHere are the " << numInts;
	cout << " number(s) you asked for." << endl;
	int x = 0;
	while (x < numInts)
	{
		cout << myArray[x] << " ";
		x++;
	}
	

	//writing the previous array into a binary file
	cout << "\n\nNow writing the numbers into a binary file..." << endl;
	try
	{
		myU.writeData(myArray, numInts);
	}
	catch (string e)
	{
		cout << e;
		return 0;
	}

	//reading data from binary file into a NEW array
	int *newArray = new int[numInts];
	
	try
	{
		newArray = myU.readData2(numInts);
	}
	catch (string e)
	{
		cout << e;
		return 0;
	}

	//doubling values and inserting them into binary tree
	cout << "\nAll values have been doubled." << endl;
	x = 0;
	int value;
	while (x < numInts)
	{
		value = (newArray[x] * 2);
		tree.insert(value);
		x++;
	}

	//BST methods are programmed to write directly
	//into output file.
	ofstream outFile("output.txt");

	cout << "\nBinary Tree Data" << endl;

	cout << "InOrder: ";
	outFile << "InOrder: ";
	tree.showInOrder(outFile);
	cout << endl;
	outFile << endl;

	cout << "PreOrder: ";
	outFile << "PreOrder: ";
	tree.showPreOrder(outFile);
	cout << endl;
	outFile << endl;

	cout << "PostOrder:	";
	outFile << "PostOrder: ";
	tree.showPostOrder(outFile);
	cout << endl;
	outFile << endl;

	outFile.close();

	delete myArray;
	delete newArray;
	myArray = nullptr;
	newArray = nullptr;

	return 0;
}